package Spravochnik_BIK;

public class classDecodingLine {
	
	String kod;
	String obozn;
	String fullName;
	public classDecodingLine(String kod, String obozn) {
		super();
		this.kod = kod;
		this.obozn = obozn;
	}
	public String getKod() {
		return kod;
	}
	public void setKod(String kod) {
		this.kod = kod;
	}
	public String getObozn() {
		return obozn;
	}
	public void setObozn(String obozn) {
		this.obozn = obozn;
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public classDecodingLine(String kod, String obozn, String fullName) {
		super();
		this.kod = kod;
		this.obozn = obozn;
		this.fullName = fullName;
	}
}
