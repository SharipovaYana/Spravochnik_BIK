package Spravochnik_BIK;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Dialog.ModalityType;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;

public class AddChangeLine_dialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private static JTextField textField_real;
	private static JTextField textField_IND;
	private static JTextField textField_NNP;
	private static JTextField textField_ADR;
	private static JTextField textField_RKS;
	private static JTextField textField_NAMEP;
	private static JTextField textField_NAMEN;
	private static JTextField textField_SROK;
	private static JTextField textField_NEWNUM;
	private static JTextField textField_TELEF;
	private static JTextField textField_REGN;
	private static JTextField textField_OKPO;
	private static JTextField textField_KSNP;
	private static JFormattedTextField formattedTextField_DT_IZM;
	private static DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	private static DefaultComboBoxModel PZN_boxModel;
	private static WideComboBox comboBox_PZN;
	private static DefaultComboBoxModel UER_boxModel;
	private static JComboBox comboBox_UER;
	private static DefaultComboBoxModel RGN_boxModel;
	private static JComboBox comboBox_RGN;
	private static DefaultComboBoxModel TNP_boxModel;
	private static JComboBox comboBox_TNP;
	private static JFormattedTextField formattedTextField_DATE_IN;
	private static  JFormattedTextField formattedTextField_DATE_CH;
	private static String oldNEWNUM = "";
	

	/**
	 * Create the dialog.
	 */
	public AddChangeLine_dialog(JPanel parent, final ArrayList<classDecodingLine> PZNarray, final ArrayList<classDecodingLine> UERarray, final ArrayList<classDecodingLine> TNParray,
			final ArrayList<classDecodingLine> RGNarray, final ResultSet rs, final boolean create, final Statement st, final int selectedRow, final ArrayList<String> NEWNUMarray,
			final Connection con) {
		setResizable(false);
		setMinimumSize(new Dimension(575, 345));
		setTitle("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C/\u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443");
		setIconImage(Toolkit.getDefaultToolkit().getImage(AddChangeLine_dialog.class.getResource("/icons/catalog.png")));
		setModalityType(ModalityType.APPLICATION_MODAL);
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setAlwaysOnTop(true);
		//setVisible(true);
		setModal(true);
		setBounds(100, 100, 584, 345);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JLabel lblReal = new JLabel("REAL");
		lblReal.setBounds(15, 19, 43, 14);
		
		textField_real = new JTextField();
		textField_real.setBounds(68, 16, 86, 20);
		textField_real.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_real.getText().length()>3)
	                e.consume();
			}
		});
		textField_real.setColumns(10);
		JLabel lblPzn = new JLabel("PZN");
		lblPzn.setBounds(15, 45, 43, 14);
		
		PZN_boxModel = new DefaultComboBoxModel();
		comboBox_PZN = new WideComboBox(PZN_boxModel);
		PZN_boxModel.addElement("");
		comboBox_PZN.setBounds(68, 42, 191, 20);
		if(PZNarray.size()>0)
		{
			for(classDecodingLine PZNcnt : PZNarray)
				PZN_boxModel.addElement(PZNcnt.getFullName());
		}
		
		JLabel lblUer = new JLabel("UER");
		lblUer.setBounds(15, 71, 43, 14);
		
		UER_boxModel = new DefaultComboBoxModel();
		comboBox_UER = new WideComboBox(UER_boxModel);
		comboBox_UER.setBounds(68, 68, 191, 20);
		if(UERarray.size()>0)
		{
			for(classDecodingLine PZNcnt : UERarray)
				UER_boxModel.addElement(PZNcnt.getObozn());
		}
		
		JLabel lblRgn = new JLabel("RGN");
		lblRgn.setBounds(15, 97, 43, 14);
		
		RGN_boxModel = new DefaultComboBoxModel();
		comboBox_RGN = new WideComboBox(RGN_boxModel);
		comboBox_RGN.setBounds(68, 94, 191, 20);
		if(RGNarray.size()>0)
		{
			for(classDecodingLine PZNcnt : RGNarray)
				RGN_boxModel.addElement(PZNcnt.getObozn());
		}
		
		TNP_boxModel = new DefaultComboBoxModel();
		comboBox_TNP = new WideComboBox(TNP_boxModel);
		TNP_boxModel.addElement("");
		comboBox_TNP.setBounds(68, 149, 86, 20);
		contentPanel.add(comboBox_TNP);
		if(TNParray.size()>0)
		{
			for(classDecodingLine PZNcnt : TNParray)
				TNP_boxModel.addElement(PZNcnt.getObozn());
		}
		
		JLabel lblInd = new JLabel("IND");
		lblInd.setBounds(15, 123, 43, 14);
		
		textField_IND = new JTextField();
		textField_IND.setBounds(68, 120, 50, 20);
		textField_IND.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_IND.getText().length()>5)
	                e.consume();
			}
		});
		textField_IND.setColumns(10);
		
		JLabel lblTnp = new JLabel("TNP");
		lblTnp.setBounds(15, 152, 43, 14);
		
		JLabel lblNnp = new JLabel("NNP");
		lblNnp.setBounds(15, 178, 43, 14);
		
		textField_NNP = new JTextField();
		textField_NNP.setBounds(68, 175, 191, 20);
		textField_NNP.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_NNP.getText().length()>24)
	                e.consume();
			}
		});
		textField_NNP.setColumns(10);
		
		JLabel lblAdr = new JLabel("ADR");
		lblAdr.setBounds(15, 204, 43, 14);
		
		textField_ADR = new JTextField();
		textField_ADR.setBounds(68, 201, 191, 20);
		textField_ADR.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_ADR.getText().length()>29)
	                e.consume();
			}
		});
		textField_ADR.setColumns(10);
		
		JLabel lblRks = new JLabel("RKS");
		lblRks.setBounds(15, 230, 43, 14);
		
		textField_RKS = new JTextField();
		textField_RKS.setBounds(68, 227, 86, 20);
		textField_RKS.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_RKS.getText().length()>8)
	                e.consume();
			}
		});
		textField_RKS.setColumns(10);
		
		JLabel lblNamep = new JLabel("NAMEP");
		lblNamep.setBounds(15, 256, 43, 14);
		
		textField_NAMEP = new JTextField();
		textField_NAMEP.setBounds(68, 253, 191, 20);
		textField_NAMEP.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_NAMEP.getText().length()>44)
	                e.consume();
			}
		});
		textField_NAMEP.setColumns(10);
		
		JLabel lblNamen = new JLabel("NAMEN");
		lblNamen.setBounds(311, 19, 55, 14);
		
		textField_NAMEN = new JTextField();
		textField_NAMEN.setBounds(376, 16, 192, 20);
		textField_NAMEN.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_NAMEN.getText().length()>29)
	                e.consume();
			}
		});
		textField_NAMEN.setColumns(10);
		
		JLabel lblSrok = new JLabel("SROK");
		lblSrok.setBounds(311, 45, 55, 14);
		
		textField_SROK = new JTextField();
		textField_SROK.setBounds(376, 42, 99, 20);
		textField_SROK.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_SROK.getText().length()>1)
	                e.consume();
			}
		});
		textField_SROK.setColumns(10);
		
		JLabel lblNewnum = new JLabel("NEWNUM");
		lblNewnum.setBounds(311, 71, 55, 14);
		
		textField_NEWNUM = new JTextField();
		textField_NEWNUM.setBounds(376, 68, 192, 20);
		textField_NEWNUM.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_NEWNUM.getText().length()>8)
	                e.consume();
			}
		});
		textField_NEWNUM.setColumns(10);
		
		JLabel lblTelef = new JLabel("TELEF");
		lblTelef.setBounds(311, 97, 55, 14);
		
		textField_TELEF = new JTextField();
		textField_TELEF.setBounds(376, 94, 179, 20);
		textField_TELEF.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_TELEF.getText().length()>24)
	                e.consume();
			}
		});
		textField_TELEF.setColumns(10);
		
		JLabel lblOkpo = new JLabel("REGN");
		lblOkpo.setBounds(311, 123, 55, 14);
		
		textField_REGN = new JTextField();
		textField_REGN.setBounds(376, 120, 86, 20);
		textField_REGN.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_REGN.getText().length()>8)
	                e.consume();
			}
		});
		textField_REGN.setColumns(10);
		
		JLabel lblOkpo_1 = new JLabel("OKPO");
		lblOkpo_1.setBounds(311, 152, 55, 14);
		
		textField_OKPO = new JTextField();
		textField_OKPO.setBounds(376, 149, 86, 20);
		textField_OKPO.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_OKPO.getText().length()>7)
	                e.consume();
			}
		});
		textField_OKPO.setColumns(10);
		
		JLabel lblDtizm = new JLabel("DT_IZM");
		lblDtizm.setBounds(311, 178, 55, 14);
		
		
		formattedTextField_DT_IZM = new JFormattedTextField(dateFormat);
		formattedTextField_DT_IZM.setBounds(376, 175, 86, 20);
		
		JLabel lblKsnp = new JLabel("KSNP");
		lblKsnp.setBounds(311, 204, 55, 14);
		
		textField_KSNP = new JTextField();
		textField_KSNP.setBounds(376, 201, 179, 20);
		textField_KSNP.addKeyListener(new KeyAdapter() 
		{
			public void keyTyped(KeyEvent e) 
			{
				if(textField_KSNP.getText().length()>19)
	                e.consume();
			}
		});
		textField_KSNP.setColumns(10);
		
		JLabel lblDatein = new JLabel("DATE_IN");
		lblDatein.setBounds(311, 230, 55, 14);
		
		formattedTextField_DATE_IN = new JFormattedTextField(dateFormat);
		formattedTextField_DATE_IN.setBounds(376, 227, 86, 20);
		
		JLabel lblDatech = new JLabel("DATE_CH");
		lblDatech.setBounds(311, 256, 55, 14);
		
		formattedTextField_DATE_CH = new JFormattedTextField(dateFormat);
		formattedTextField_DATE_CH.setBounds(376, 253, 86, 20);
		contentPanel.setLayout(null);
		contentPanel.add(lblRgn);
		contentPanel.add(comboBox_RGN);
		contentPanel.add(lblTelef);
		contentPanel.add(textField_TELEF);
		contentPanel.add(lblInd);
		contentPanel.add(textField_IND);
		contentPanel.add(lblOkpo);
		contentPanel.add(textField_REGN);
		contentPanel.add(lblTnp);
		contentPanel.add(lblOkpo_1);
		contentPanel.add(textField_OKPO);
		contentPanel.add(lblNnp);
		contentPanel.add(textField_NNP);
		contentPanel.add(lblDtizm);
		contentPanel.add(formattedTextField_DT_IZM);
		contentPanel.add(lblAdr);
		contentPanel.add(textField_ADR);
		contentPanel.add(lblKsnp);
		contentPanel.add(textField_KSNP);
		contentPanel.add(lblRks);
		contentPanel.add(textField_RKS);
		contentPanel.add(lblDatein);
		contentPanel.add(formattedTextField_DATE_IN);
		contentPanel.add(lblNamep);
		contentPanel.add(textField_NAMEP);
		contentPanel.add(lblDatech);
		contentPanel.add(formattedTextField_DATE_CH);
		contentPanel.add(lblReal);
		contentPanel.add(textField_real);
		contentPanel.add(lblNamen);
		contentPanel.add(lblUer);
		contentPanel.add(comboBox_UER);
		contentPanel.add(lblPzn);
		contentPanel.add(comboBox_PZN);
		contentPanel.add(lblNewnum);
		contentPanel.add(lblSrok);
		contentPanel.add(textField_NAMEN);
		contentPanel.add(textField_NEWNUM);
		contentPanel.add(textField_SROK);
		
		JLabel label = new JLabel("\u0414\u0414.\u041C\u041C.\u0413\u0413\u0413\u0413");
		label.setForeground(Color.LIGHT_GRAY);
		label.setBounds(472, 178, 83, 14);
		contentPanel.add(label);
		
		JLabel label_1 = new JLabel("\u0414\u0414.\u041C\u041C.\u0413\u0413\u0413\u0413");
		label_1.setForeground(Color.LIGHT_GRAY);
		label_1.setBounds(472, 230, 83, 14);
		contentPanel.add(label_1);
		
		JLabel label_2 = new JLabel("\u0414\u0414.\u041C\u041C.\u0413\u0413\u0413\u0413");
		label_2.setForeground(Color.LIGHT_GRAY);
		label_2.setBounds(472, 256, 83, 14);
		contentPanel.add(label_2);
		
		JLabel label_3 = new JLabel("*");
		label_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_3.setForeground(Color.RED);
		label_3.setBounds(46, 69, 21, 14);
		contentPanel.add(label_3);
		
		JLabel label_4 = new JLabel("*");
		label_4.setForeground(Color.RED);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_4.setBounds(46, 97, 21, 14);
		contentPanel.add(label_4);
		
		JLabel label_5 = new JLabel("*");
		label_5.setForeground(Color.RED);
		label_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_5.setBounds(56, 256, 21, 14);
		contentPanel.add(label_5);
		
		JLabel label_6 = new JLabel("*");
		label_6.setForeground(Color.RED);
		label_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_6.setBounds(357, 19, 21, 14);
		contentPanel.add(label_6);
		
		JLabel label_7 = new JLabel("*");
		label_7.setForeground(Color.RED);
		label_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_7.setBounds(364, 69, 21, 14);
		contentPanel.add(label_7);
		
		JLabel label_8 = new JLabel("*");
		label_8.setForeground(Color.RED);
		label_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_8.setBounds(357, 44, 21, 14);
		contentPanel.add(label_8);
		
		JLabel label_9 = new JLabel("*");
		label_9.setForeground(Color.RED);
		label_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_9.setBounds(357, 177, 21, 14);
		contentPanel.add(label_9);
		
		JLabel label_10 = new JLabel("*");
		label_10.setForeground(Color.RED);
		label_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_10.setBounds(357, 229, 21, 14);
		contentPanel.add(label_10);
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
							String REAL = textField_real.getText();
							String PZN = "";
							for(int i=0; i<PZNarray.size();i++)
							{
								if(i==comboBox_PZN.getSelectedIndex()-1)
									PZN = PZNarray.get(i).getKod();
							}
							//System.out.println("PZN=" + PZN);
							String UER = "";
							for(int i=0;i<UERarray.size();i++)
							{
								if(i==comboBox_UER.getSelectedIndex())
									UER = UERarray.get(i).getKod();
							}
							//System.out.println("UER=" + UER);
							String RGN = "";
							for(int i=0;i<RGNarray.size();i++)
							{
								if(i==comboBox_RGN.getSelectedIndex())
									RGN = RGNarray.get(i).getKod();
							}
							//System.out.println("RGN=" + RGN);
							String IND = textField_IND.getText();
							String TNP = ""; 
							for(int i=0; i<TNParray.size();i++)
							{
								if(i==comboBox_TNP.getSelectedIndex()-1)
									TNP = TNParray.get(i).getKod();
							}
							//System.out.println("TNP=" + TNP);
							
							String NNP = textField_NNP.getText();
							String ADR = textField_ADR.getText();
							String RKS = textField_RKS.getText();
							String NAMEP = textField_NAMEP.getText();
							String NAMEN = textField_NAMEP.getText();
							String SROK = textField_SROK.getText();
							String NEWNUM = textField_NEWNUM.getText();
							String TELEF = textField_TELEF.getText(); 
							String REGN = textField_REGN.getText();
							String OKPO = textField_OKPO.getText();
							Date DT_IZM = getDate(formattedTextField_DT_IZM.getText(), dateFormat);
							String KSNP = textField_KSNP.getText();
							Date DATE_IN = getDate(formattedTextField_DATE_IN.getText(), dateFormat);
							Date DATE_CH = getDate(formattedTextField_DATE_CH.getText(), dateFormat);
							if(UER.isEmpty() || RGN.isEmpty() || NAMEP.isEmpty() || NAMEN.isEmpty() || SROK.isEmpty() || NEWNUM.isEmpty() ||
									DT_IZM==null || DATE_IN==null)
								JOptionPane.showMessageDialog(contentPanel, "��������� ��� ������������ ���� (*)", "������", JOptionPane.ERROR_MESSAGE);
							else
							{
								boolean save = true;
								if(!oldNEWNUM.equals(NEWNUM))
									save = chekUniqNEWNUM(NEWNUMarray, NEWNUM);
								if(save)
								{
									try {
										createChangeLine(rs, REAL, PZN, UER, RGN, IND, TNP, NNP, ADR, RKS, NAMEP, NAMEN, SROK, NEWNUM, TELEF, REGN, OKPO, 
												DT_IZM, KSNP, DATE_IN, DATE_CH, create, selectedRow, con);
										dispose();
									} catch (SQLException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
								else
									JOptionPane.showMessageDialog(contentPanel, "�������� NEWNUM �� ���������", "������", JOptionPane.ERROR_MESSAGE);
							}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("\u041E\u0442\u043C\u0435\u043D\u0430");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		setLocationRelativeTo(parent);
		if(create==false)
		{
			try {
				oldNEWNUM = fillForm(rs, selectedRow, PZNarray, UERarray, TNParray, RGNarray, dateFormat);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	private static void createChangeLine(ResultSet rs, String REAL, String PZN, String UER, String RGN, String IND, String TNP, 
			String NNP, String ADR, String RKS, String NAMEP, String NAMEN, String SROK, String NEWNUM, String TELEF, String REGN,
			String OKPO, Date DT_IZM, String KSNP, Date DATE_IN, Date DATE_CH, boolean create, int selectedRow, Connection con) throws SQLException
	{
		//rs.first();
		rs.beforeFirst();
		if(create==true)
			rs.moveToInsertRow();
		else
		{
			int i=0;
			while (rs.next()) 
			{
				if(i==selectedRow)
					break;
				i++;
			}
			System.out.println(i);
		}
		Calendar cal = new GregorianCalendar();
		String VKEY = new SimpleDateFormat("HHmmssS").format(cal.getTime());
		VKEY = VKEY.substring(1);
		rs.updateString("VKEY", VKEY);
		rs.updateString("REAL", REAL);
		rs.updateString("PZN", PZN);
		rs.updateString("UER", UER);
		rs.updateString("RGN", RGN);
		rs.updateString("IND", IND);
		rs.updateString("TNP", TNP);
		rs.updateString("NNP", NNP);
		rs.updateString("ADR", ADR);
		rs.updateString("RKC", RKS);
		rs.updateString("NAMEP", NAMEP);
		rs.updateString("NAMEN", NAMEN);
		rs.updateString("SROK", SROK);
		rs.updateString("NEWNUM", NEWNUM);
		rs.updateString("TELEF", TELEF);
		rs.updateString("REGN", REGN);
		rs.updateString("OKPO", OKPO);
		rs.updateDate("DT_IZM", DT_IZM);
		rs.updateString("KSNP", KSNP);
		rs.updateDate("DATE_IN", DATE_IN);
		rs.updateDate("DATE_CH", DATE_CH);
		if(create==true)
		{
			/*String sql = "INSERT INTO BNKSEEK ("
				    + "VKEY, "
				    + "REAL, "
				    + "PZN, "
				    + "UER, "
				    + "RGN, "
				    + "IND, "
				    + "TNP, "
				    + "NNP, "
				    + "ADR, "
				    + "RKC, "
				    + "NAMEP, "
				    + "NAMEN, "
				    + "NEWNUM, "
				    + "NEWKS, "
				    + "PERMFO, "
				    + "SROK, "
				    + "AT1, "
				    + "AT2, "
				    + "TELEF, "
				    + "REGN, "
				    + "OKPO, "
				    + "DT_IZM, "
				    + "CKS, "
				    + "KSNP, "
				    + "DATE_IN, "
				    + "DATE_CH, "
				    + "DT_IZMR, "
				    + "VKEYDEL) "
				    +  "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, VKEY);
			pstmt.setString(2, REAL);
			pstmt.setString(3, PZN);
			pstmt.setString(4, UER);
			pstmt.setString(5, RGN);
			pstmt.setString(6, IND);
			pstmt.setString(7, TNP);
			pstmt.setString(8, NNP);
			pstmt.setString(9, ADR);
			pstmt.setString(10, RKS);
			pstmt.setString(11, NAMEP);
			pstmt.setString(12, NAMEN);
			pstmt.setString(13, SROK);
			pstmt.setString(14, NEWNUM);
			pstmt.setString(15, "");
			pstmt.setString(16, "");
			pstmt.setString(17, "");
			pstmt.setString(18, "");
			pstmt.setString(19, TELEF);
			pstmt.setString(20, REGN);
			pstmt.setString(21, OKPO);
			pstmt.setDate(22, DT_IZM);
			pstmt.setString(23, "");
			pstmt.setString(24, KSNP);
			pstmt.setDate(25, DATE_IN);
			pstmt.setDate(26, DATE_CH);
			pstmt.setString(27, VKEY);
			pstmt.setDate(28, null);
			pstmt.executeUpdate(); */
			rs.insertRow();
		}
		else
			rs.updateRow();
		
		//rs.moveToCurrentRow();
	}
	private static Date getDate(String dateStr, DateFormat dateFormat)
	{
		java.util.Date date = null;
		if(!dateStr.isEmpty())
		{
			try {
				date = dateFormat.parse(dateStr);
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		java.sql.Date dateRet = null;
		if(date!=null)
		{
			dateRet = new java.sql.Date(date.getTime());
		}
		return dateRet;
	}
	private static boolean chekUniqNEWNUM(ArrayList<String> NEWNUMarray, String str)
	{
		boolean ans = true;
		for(String currentStr : NEWNUMarray)
		{
			if(currentStr.equals(str))
			{
				//System.out.println("find NEWNUM");
				ans=false;
				break;
			}
		}
		return ans;
	}
	
	private static String fillForm(ResultSet rs, int selectedRow, final ArrayList<classDecodingLine> PZNarray, final ArrayList<classDecodingLine> UERarray, 
			final ArrayList<classDecodingLine> TNParray,
			final ArrayList<classDecodingLine> RGNarray, DateFormat dateFormat) throws SQLException
	{
		String oldNEWNUM = "";
		int i=0;
		String PZN = "";
		String UER = "";
		String TNP = "";
		String RGN = "";
		Date DT_IZM = null;
		Date DATE_IN = null;
		Date DATE_CH = null;
		while (rs.next()) 
		{
			if(i==selectedRow)
			{
				PZN = Spravochnik_BIK_frame.getPZNUERStr(rs.getString(3), PZNarray, true);
				comboBox_PZN.setSelectedItem(PZN);
				UER = Spravochnik_BIK_frame.getPZNUERStr(rs.getString(4), UERarray, false);
				comboBox_UER.setSelectedItem(UER);
				TNP = Spravochnik_BIK_frame.getPZNUERStr(rs.getString(7), TNParray, false);
				comboBox_TNP.setSelectedItem(TNP);
				RGN = Spravochnik_BIK_frame.getPZNUERStr(rs.getString(5), RGNarray, false);
				comboBox_RGN.setSelectedItem(RGN);
			
				oldNEWNUM = rs.getString(13);
				textField_real.setText(rs.getString(2));
				textField_IND.setText(rs.getString(6));
				textField_NNP.setText(rs.getString(8));
				textField_ADR.setText(rs.getString(9));
				textField_RKS.setText(rs.getString(10));
				textField_NAMEP.setText(rs.getString(11));
				textField_NAMEN.setText(rs.getString(12));
				textField_NEWNUM.setText(oldNEWNUM);
				textField_TELEF.setText(rs.getString(19));
				textField_REGN.setText(rs.getString(20));
				textField_OKPO.setText(rs.getString(21));
				textField_KSNP.setText(rs.getString(24));
				textField_SROK.setText(rs.getString(16));
				DT_IZM=rs.getDate(22);
				if(DT_IZM!=null)
					formattedTextField_DT_IZM.setText(dateFormat.format(DT_IZM));
				DATE_IN=rs.getDate(25);
				if(DATE_IN!=null)
					formattedTextField_DATE_IN.setText(dateFormat.format(DATE_IN));
				DATE_CH=rs.getDate(26);
				if(DATE_CH!=null)
					formattedTextField_DATE_CH.setText(dateFormat.format(DATE_CH));

				break;
			
			}
			i++;
			PZN = "";
			UER = "";
			TNP = "";
			RGN = "";
			DT_IZM = null;
			DATE_IN = null;
			DATE_CH = null;
		}
		rs.beforeFirst();
		return oldNEWNUM;
	}
}
