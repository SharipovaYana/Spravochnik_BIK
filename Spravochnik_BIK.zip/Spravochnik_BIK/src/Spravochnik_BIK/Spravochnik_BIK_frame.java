package Spravochnik_BIK;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Point;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Dimension;

public class Spravochnik_BIK_frame extends JFrame {

	private JPanel contentPane;
	private static JTable table;
	private static DefaultTableModel tableModel;
	private static ArrayList<classDecodingLine> PZNarray = new ArrayList <classDecodingLine>();
	private static ArrayList<classDecodingLine> UERarray = new ArrayList <classDecodingLine>();
	private static ArrayList<classDecodingLine> TNParray = new ArrayList <classDecodingLine>();
	private static ArrayList<classDecodingLine> RGNarray = new ArrayList <classDecodingLine>();
	private static ArrayList<String> NEWNUMarray = new ArrayList <String>();
	private static DefaultComboBoxModel filter_boxModel;
	private static  JComboBox comboBox_filter;
	private static JTextField textField_filter;
	private static DefaultComboBoxModel filter_PZN_boxModel;
	private static WideComboBox comboBox_filterPZN;
	private JButton button_find;
	private static Statement st = null;
	private static ResultSet rs;
	private static Connection con;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Spravochnik_BIK_frame frame = new Spravochnik_BIK_frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Spravochnik_BIK_frame() {
		setMinimumSize(new Dimension(1030, 530));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Spravochnik_BIK_frame.class.getResource("/icons/catalog.png")));
		setTitle("\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0411\u0418\u041A");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1031, 525);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		this.addWindowListener(new WindowAdapter(){
		    public void windowClosing(WindowEvent evt){
		    	try {
					rs.close();
					st.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton button_add_line = new JButton("");
		button_add_line.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				/*try {
					rs = readDataBase(st, true, false);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}*/
				AddChangeLine_dialog dialog = new AddChangeLine_dialog(contentPane, PZNarray, UERarray, TNParray, RGNarray, rs, true, st, 0, NEWNUMarray, con);
				dialog.setVisible(true);
				try {
					rs = readDataBase(st, true, true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button_add_line.setToolTipText("\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0443");
		button_add_line.setIcon(new ImageIcon(Spravochnik_BIK_frame.class.getResource("/icons/add_16.png")));
		
		JButton button_change_line = new JButton("");
		button_change_line.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
				AddChangeLine_dialog dialog = new AddChangeLine_dialog(contentPane, PZNarray, UERarray, TNParray, RGNarray, rs, false, st, table.getSelectedRow(), NEWNUMarray, con);
				dialog.setVisible(true);
				try {
					rs = readDataBase(st, true, true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button_change_line.setIcon(new ImageIcon(Spravochnik_BIK_frame.class.getResource("/icons/streply.png")));
		button_change_line.setToolTipText("\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443");
		
		JButton button_delete_line = new JButton("");
		button_delete_line.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					deleteRow(rs, table.getSelectedRow());
					rs = readDataBase(st, true, true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button_delete_line.setIcon(new ImageIcon(Spravochnik_BIK_frame.class.getResource("/icons/delete_16.png")));
		button_delete_line.setToolTipText("\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443");
		
		JLabel label = new JLabel("\u041D\u0430\u0439\u0442\u0438 \u043F\u043E:");
		
		filter_boxModel = new DefaultComboBoxModel();
		filter_boxModel.addElement("���");
		filter_boxModel.addElement("������");
		filter_boxModel.addElement("��� (PZN)");
		comboBox_filter = new JComboBox(filter_boxModel);
		
		textField_filter = new JTextField();
		textField_filter.setColumns(10);
		
		
		filter_PZN_boxModel = new DefaultComboBoxModel();
		comboBox_filterPZN = new WideComboBox(filter_PZN_boxModel);
		comboBox_filterPZN.setEnabled(false);
		
		comboBox_filter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				textField_filter.setText("");
				if(comboBox_filter.getSelectedItem().equals("���") || comboBox_filter.getSelectedItem().equals("������"))
				{
					textField_filter.setEnabled(true);
					textField_filter.setEditable(true);
					comboBox_filterPZN.setEnabled(false);
				}
				else
				{
					textField_filter.setEnabled(false);
					textField_filter.setEditable(false);
					comboBox_filterPZN.setEnabled(true);
				}
			}
		});
		
		button_find = new JButton("");
		button_find.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(st==null)
						st = connectDBF();
					rs = readDataBase(st, true, true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_find.setToolTipText("\u041D\u0430\u0439\u0442\u0438");
		button_find.setIcon(new ImageIcon(Spravochnik_BIK_frame.class.getResource("/icons/edit-find.png")));
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 988, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(button_add_line)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(button_change_line)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(button_delete_line)
							.addGap(162)
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(comboBox_filter, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_filter, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox_filterPZN, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(button_find)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addComponent(button_change_line)
							.addComponent(button_delete_line)
							.addComponent(button_add_line))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(comboBox_filter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(label)
								.addComponent(textField_filter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(comboBox_filterPZN, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(button_find))
							.addGap(3)))
					.addGap(19)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 409, Short.MAX_VALUE)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		
		
		
		
		tableModel = new DefaultTableModel(){
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(tableModel);
		table.addMouseListener(new MouseAdapter() {
		    public void mousePressed(MouseEvent mouseEvent) {
		        JTable table =(JTable) mouseEvent.getSource();
		        Point point = mouseEvent.getPoint();
		        int row = table.rowAtPoint(point);
		        if (mouseEvent.getClickCount() == 2) {
		        	AddChangeLine_dialog dialog = new AddChangeLine_dialog(contentPane, PZNarray, UERarray, TNParray, RGNarray, rs, false, st, row, NEWNUMarray, con);
					dialog.setVisible(true);
					try {
						rs = readDataBase(st, true, true);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		    }
		});
		
		scrollPane.setViewportView(table);
		
		setLocationRelativeTo(null);
		
		try {
			st = connectDBF();
			readReferenceInformation(st);
			rs = readDataBase(st, false, true);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(PZNarray.size()>0)
		{
			for(classDecodingLine PZNcnt : PZNarray)
				filter_PZN_boxModel.addElement(PZNcnt.getFullName());
				
		}
	}
	private static Statement connectDBF() throws ClassNotFoundException, SQLException
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        String url = "jdbc:odbc:Driver={Microsoft Access dBASE Driver (*.dbf, *.ndx, *.mdx)};DBQ=D:/DB_BIK";
        con = DriverManager.getConnection(url);
        Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        	    ResultSet.CONCUR_UPDATABLE);
        return st;
	}
	
	private static void readReferenceInformation(Statement st) throws SQLException
	{
		 /*
         * ������ ����������� PZN � ������ � �����. ������
         */
        PZNarray.clear();
        ResultSet rsPZN = st.executeQuery("SELECT PZN,IMY,NAME FROM PZN ORDER BY NAME");
        //ResultSetMetaData rsmd = rsPZN.getMetaData();
        //System.out.println(rsmd.getColumnName(2) + "|" + rsmd.getColumnName(3) + "|" + rsmd.getColumnName(4));
        while (rsPZN.next()) {
        	//System.out.println(rsPZN.getString(1) + "|" + rsPZN.getString(2) + "|" + rsPZN.getString(3) + "|" + rsPZN.getString(4));
        	PZNarray.add(new classDecodingLine(rsPZN.getString(1), rsPZN.getString(2), rsPZN.getString(3)));
        }
        
        /*
         * ������ ����������� UER � ������ � �����. ������
         */
        ResultSet rsUER = st.executeQuery("SELECT UER, UERNAME FROM UER ORDER BY UERNAME");
        while (rsUER.next()) {
        	UERarray.add(new classDecodingLine(rsUER.getString(1), rsUER.getString(2)));
        	//System.out.println(rsUER.getString(1) + "=" + rsUER.getString(2) + "=" + rsUER.getString(3));
        }
        
        /*
         * ������ ����������� TNP � ������ � �����. ������
         */
        ResultSet rsTNP = st.executeQuery("SELECT TNP, SHORTNAME FROM TNP ORDER BY SHORTNAME");
        while (rsTNP.next()) {
        	TNParray.add(new classDecodingLine(rsTNP.getString(1), rsTNP.getString(2)));
        }
        
        /*
         * ������ ����������� RGN � ������ � �����. ������
         */
        ResultSet rsRGN = st.executeQuery("SELECT RGN, NAME FROM REG  ORDER BY NAME");
        while (rsRGN.next()) {
        	RGNarray.add(new classDecodingLine(rsRGN.getString(1), rsRGN.getString(2)));
        }
	}
	public static ResultSet readDataBase(Statement st, boolean filter, boolean refreshTable) throws SQLException
	{
		String query = "SELECT * FROM BNKSEEK ORDER BY DT_IZM DESC";
		if(filter==true)
		{
			if(comboBox_filter.getSelectedItem().equals("���"))
			{
				if(!textField_filter.getText().isEmpty())
					query = "SELECT * FROM BNKSEEK WHERE NEWNUM LIKE '" + textField_filter.getText() + "' ORDER BY DT_IZM DESC";
			}
			else if(comboBox_filter.getSelectedItem().equals("������"))
			{
				if(!textField_filter.getText().isEmpty())
				{
					String rgnKod = "";
					for(classDecodingLine PZNcnt : RGNarray)
						if(PZNcnt.getObozn()!=null)
							if(PZNcnt.getObozn().equals(textField_filter.getText()))
							{
								rgnKod = PZNcnt.getKod();
								break;
							}
					
					query = "SELECT * FROM BNKSEEK WHERE RGN LIKE '" + rgnKod + "' ORDER BY DT_IZM DESC";
				}
			}
			else if(comboBox_filter.getSelectedItem().equals("��� (PZN)"))
			{
				if(comboBox_filterPZN.getSelectedIndex()>-1)
				{
					String pznKod = "";
					for(classDecodingLine PZNcnt : PZNarray)
						if(PZNcnt.getFullName().equals(comboBox_filterPZN.getSelectedItem()))
						{
							pznKod = PZNcnt.getKod();
							break;
						}
					
					query = "SELECT * FROM BNKSEEK WHERE PZN LIKE '"+ pznKod + "' ORDER BY DT_IZM DESC";
				}
			}
			try {
				if(st==null)
					st = connectDBF();
				//rs = readDataBase(st, query);
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
        ResultSet rs = st.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
        System.out.println(rsmd.getColumnCount());
        if(refreshTable==true)
        	fill_table(rs);
        //rs.beforeFirst();
        return rs;
        //con.close();
	}
	private static void fill_table(ResultSet rs) throws SQLException
	{
		rs.last();
		int size = rs.getRow();
		System.out.println(size);
		rs.beforeFirst();
		Object obj[][] = new Object[size][];
		int i=0;
		String PZN = "";
		String UER = "";
		String TNP = "";
		String RGN = "";
		String NEWNUM = "";
		while (rs.next()) 
		{
			PZN = getPZNUERStr(rs.getString(3), PZNarray, false);
			UER = getPZNUERStr(rs.getString(4), UERarray, false);
			TNP = getPZNUERStr(rs.getString(7), TNParray, false);
			RGN = getPZNUERStr(rs.getString(5), RGNarray, false);
			NEWNUM = rs.getString(13);
			NEWNUMarray.add(NEWNUM);
			
			obj[i] =  new Object[]{rs.getString(2), PZN, UER, RGN, rs.getString(6), TNP, rs.getString(8),
					rs.getString(9), rs.getString(10), rs.getString(11), NEWNUM, rs.getString(19), rs.getString(20),
					rs.getString(21), rs.getString(22), rs.getString(24), rs.getString(25), rs.getString(26)};
			i++;
			PZN = "";
			UER = "";
			TNP = "";
			RGN = "";
			NEWNUM = "";
		}
		tableModel.setDataVector(obj, 
				new Object[] {
								"REAl",
								"PZN",
								"UER",
								"RGN",
								"IND",
								"TNP",
								"NNP",
								"ADR",
								"RKC",
								"NAMEP",
								"NEWNUM",
								"TELEF",
								"REGN",
								"OKPO",
								"DT_IZM",
								"KSNP",
								"DATE_IN",
								"DATE_CH"});
		
		table.getColumnModel().getColumn(0).setMinWidth(45);
		table.getColumnModel().getColumn(0).setMaxWidth(45);
		table.getColumnModel().getColumn(1).setMinWidth(40);
		table.getColumnModel().getColumn(1).setMaxWidth(40);
		//table.getColumnModel().getColumn(2).setMinWidth(40);
		//table.getColumnModel().getColumn(2).setMaxWidth(40);
		//table.getColumnModel().getColumn(3).setMinWidth(40);
		//table.getColumnModel().getColumn(3).setMaxWidth(40);
		table.getColumnModel().getColumn(4).setMinWidth(60);
		table.getColumnModel().getColumn(4).setMaxWidth(60);
		table.getColumnModel().getColumn(5).setMaxWidth(50);
		table.getColumnModel().getColumn(8).setMaxWidth(80);
		table.getColumnModel().getColumn(10).setMaxWidth(80);
		table.getColumnModel().getColumn(13).setMaxWidth(70);
		table.getColumnModel().getColumn(14).setMaxWidth(80);
		table.getColumnModel().getColumn(16).setMaxWidth(80);
		table.getColumnModel().getColumn(17).setMaxWidth(80);
		
		rs.beforeFirst();
	}
	
	private static void deleteRow(ResultSet rs, int selectedRow) throws SQLException
	{
		if(rs!=null)
		{
			rs.beforeFirst();
			int i=0;
			while (rs.next()) 
			{
				if(i==selectedRow)
				{
					rs.deleteRow();
					System.out.println("deleted row: " + i);
					break;
				}
				i++;
			}
			rs.beforeFirst();
		}
	}
	
	
	public static String getPZNUERStr(String pznCod, ArrayList<classDecodingLine> PZNarray, boolean full_name)
	{
		String pzn = "";
		if(pznCod!=null)
			for(classDecodingLine PZNcnt : PZNarray)
				if(PZNcnt.getKod()!=null)
					if(PZNcnt.getKod().equals(pznCod))
					{
						if(full_name)
							pzn = PZNcnt.getFullName();
						else pzn = PZNcnt.getObozn();
						break;
					}
		return pzn;
	}
	
	
}
